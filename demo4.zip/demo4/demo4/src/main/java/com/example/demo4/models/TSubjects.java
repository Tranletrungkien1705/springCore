/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.demo4.models;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author PC
 */
@Entity
@Table(name = "t_subjects")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TSubjects.findAll", query = "SELECT t FROM TSubjects t"),
    @NamedQuery(name = "TSubjects.findById", query = "SELECT t FROM TSubjects t WHERE t.id = :id"),
    @NamedQuery(name = "TSubjects.findByName", query = "SELECT t FROM TSubjects t WHERE t.name = :name")})
public class TSubjects implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Size(max = 100)
    @Column(name = "name")
    private String name;
    @JoinTable(name = "t_subject_teacher", joinColumns = {
        @JoinColumn(name = "subject_id", referencedColumnName = "id")}, inverseJoinColumns = {
        @JoinColumn(name = "teacher_id", referencedColumnName = "id")})
    @ManyToMany
    private Collection<TTeachers> tTeachersCollection;
    @OneToMany(mappedBy = "subjectId")
    private Collection<TMarks> tMarksCollection;

    public TSubjects() {
    }

    public TSubjects(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @XmlTransient
    public Collection<TTeachers> getTTeachersCollection() {
        return tTeachersCollection;
    }

    public void setTTeachersCollection(Collection<TTeachers> tTeachersCollection) {
        this.tTeachersCollection = tTeachersCollection;
    }

    @XmlTransient
    public Collection<TMarks> getTMarksCollection() {
        return tMarksCollection;
    }

    public void setTMarksCollection(Collection<TMarks> tMarksCollection) {
        this.tMarksCollection = tMarksCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TSubjects)) {
            return false;
        }
        TSubjects other = (TSubjects) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.example.demo4.models.TSubjects[ id=" + id + " ]";
    }
    
}
