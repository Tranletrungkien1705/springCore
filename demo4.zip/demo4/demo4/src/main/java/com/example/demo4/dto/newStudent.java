package com.example.demo4.dto;

import java.util.List;

public class newStudent {
    private int id;
    private String name;
    private String classs;
    private List<listMark> diemThi;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClasss() {
        return classs;
    }

    public void setClasss(String classs) {
        this.classs = classs;
    }

    public List<listMark> getDiemThi() {
        return diemThi;
    }

    public void setDiemThi(List<listMark> diemThi) {
        this.diemThi = diemThi;
    }
}
