package com.example.demo4.repository;

import com.example.demo4.models.TClasses;
import org.springframework.data.jpa.repository.JpaRepository;

public interface classRepo extends JpaRepository<TClasses,Integer> {
}
