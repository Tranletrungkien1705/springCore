/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.demo4.models;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author PC
 */
@Entity
@Table(name = "t_teachers")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "TTeachers.findAll", query = "SELECT t FROM TTeachers t"),
    @NamedQuery(name = "TTeachers.findById", query = "SELECT t FROM TTeachers t WHERE t.id = :id"),
    @NamedQuery(name = "TTeachers.findByFirstName", query = "SELECT t FROM TTeachers t WHERE t.firstName = :firstName"),
    @NamedQuery(name = "TTeachers.findByLastName", query = "SELECT t FROM TTeachers t WHERE t.lastName = :lastName")})
public class TTeachers implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Size(max = 100)
    @Column(name = "first_name")
    private String firstName;
    @Size(max = 100)
    @Column(name = "last_name")
    private String lastName;
    @ManyToMany(mappedBy = "tTeachersCollection")
    private Collection<TSubjects> tSubjectsCollection;

    public TTeachers() {
    }

    public TTeachers(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @XmlTransient
    public Collection<TSubjects> getTSubjectsCollection() {
        return tSubjectsCollection;
    }

    public void setTSubjectsCollection(Collection<TSubjects> tSubjectsCollection) {
        this.tSubjectsCollection = tSubjectsCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof TTeachers)) {
            return false;
        }
        TTeachers other = (TTeachers) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.example.demo4.models.TTeachers[ id=" + id + " ]";
    }
    
}
