package com.example.demo4.repository;

import com.example.demo4.models.TStudents;
import org.springframework.data.jpa.repository.JpaRepository;

public interface studentRepo extends JpaRepository<TStudents,Integer> {
}
