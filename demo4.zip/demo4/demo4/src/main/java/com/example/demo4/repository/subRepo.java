package com.example.demo4.repository;

import com.example.demo4.models.TSubjects;
import org.springframework.data.jpa.repository.JpaRepository;

public interface subRepo extends JpaRepository<TSubjects,Integer> {
}
