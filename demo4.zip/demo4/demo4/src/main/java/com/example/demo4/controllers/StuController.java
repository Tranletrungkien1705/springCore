package com.example.demo4.controllers;

import com.example.demo4.dto.listMark;
import com.example.demo4.models.TClasses;
import com.example.demo4.models.TMarks;
import com.example.demo4.models.TStudents;
import com.example.demo4.dto.newStudent;
import com.example.demo4.repository.classRepo;
import com.example.demo4.repository.markRepo;
import com.example.demo4.repository.studentRepo;
import com.example.demo4.repository.subRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import javax.websocket.server.PathParam;
import java.util.ArrayList;
import java.util.List;

@Controller
@Transactional
public class StuController {
    @Autowired
    private studentRepo studentRepo;
    @Autowired
    private classRepo classRepo;
    @Autowired
    private markRepo markRepo;
    @Autowired
    private subRepo subRepo;

    @GetMapping("/")
    public String GoHome(Model model){
        List<TStudents> students = studentRepo.findAll();
        List<newStudent> newStudent1s = new ArrayList<>();
        for (TStudents student: students) {
            newStudent ns = new  newStudent();
            ns.setId(student.getId());
            ns.setClasss(classRepo.findById(student.getClassId()).get().getName());
            ns.setName(student.getName());
            List<TMarks> dts = markRepo.findMarkBySi(student.getId());
            List<listMark> lms = new ArrayList<>();
            for (TMarks dt :dts) {
                listMark lm = new listMark();
                lm.setMark(dt.getMark());
                lm.setSubject(subRepo.findById(dt.getSubjectId()).get().getName() );
                lms.add(lm);
            }
            ns.setDiemThi(lms);
            newStudent1s.add(ns);
        }
        model.addAttribute("sinhViens",newStudent1s);
        return "index";
    }
    @GetMapping("/chuan-bi-assign")
    public String chuanBiAssign(@PathParam("id") int id, Model model){
        TStudents sv = studentRepo.findById(id).get();
        model.addAttribute("svId", sv.getId());
        model.addAttribute("svName", sv.getName());

        List<TClasses> khoaHocs = classRepo.findAll();
        model.addAttribute("khoaHocs", khoaHocs);
        return "assign";
    }

    @PostMapping("/AssignDi")
    public String assignDi(HttpServletRequest rq){
        int svId = Integer.parseInt(rq.getParameter("svId")) ;
        int khId = Integer.parseInt(rq.getParameter("khId"));
        TStudents t = new TStudents();
        TStudents t1 = studentRepo.findById(svId).get();
        t.setId(svId);
        t.setName(t1.getName());
        t.setClassId(khId);
        studentRepo.save(t);
        return "redirect:/";
    }
}
